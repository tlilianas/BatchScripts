package model.implementation;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class calcRPNTest {

  @Test
  public void evalExpressionTest(){
    System.out.println("Inside evalExpressionTest()");
    assertEquals(21.0, calcRPN.evalExpression("3 2 5 + * "), 0);
  }

  @Test
  public void evalCalcHistory(){
    System.out.println("Inside evalExpressionTest()");
    assertEquals("Feature to be implemented, probably through a database.", calcRPN.history());
  }
}
