package model.implementation;

import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedList;
import java.util.function.BiFunction;

public class calcRPN {

  public static String history() {
    return "Feature to be implemented, probably through a database.";
  }

  public static double evalExpression(String expression) {

    //to be moved to a separate method that will analyse the expression
    //alert if any non numeric / alert if unsupported type.
    if(expression.isEmpty()) {
      throw new IllegalArgumentException("Invalid Reverse Polish Expression");
    }

    Deque<Double> elementsStack = new LinkedList<>();

    Arrays.asList(expression.split(" ")).stream().forEach(element -> {
      evaluationExpressionElement(elementsStack, element);
    });
    return elementsStack.pop();
  }

  //inverting elements order in subtraction and division because they are not commutative
  private static void evaluationExpressionElement(Deque<Double> elementsStack, String element) {
    switch(element){
      case "+":
        calculate(elementsStack, (n1, n2) -> n2 + n1);
        break;
      case "-":
        calculate(elementsStack, (n1, n2) -> n2 - n1);
        break;
      case "*":
        calculate(elementsStack, (n1, n2) -> n2 * n1);
        break;
      case "/":
        calculate(elementsStack, (n1, n2) -> n2 / n1);
        break;
      default:
        elementsStack.push(Double.parseDouble(element));
    }
  }

  private static Deque<Double> calculate(Deque<Double> elementsStack, BiFunction<Double, Double, Double> operation) {
    elementsStack.push(operation.apply(elementsStack.pop(), elementsStack.pop()));
    return elementsStack;
  }

  public static void main(String[] args){
    //use logger instead of standard println
    String expression = "1 2 +";
    System.out.println(evalExpression(expression));
    String expression2 = "4 13 5 / +";
    System.out.println(evalExpression(expression2));
    String expression3 ="10 6 9 3 + -11 * / * 17 + 5 +";
    System.out.println(evalExpression(expression3));
  }
}
